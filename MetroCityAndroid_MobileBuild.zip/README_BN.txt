Metro City 3D — Android Studio project

গুরুত্বপূর্ণ:
- এটি Android Studio-তে APK build করার project; তৈরি APK ফাইল নয়।
- Three.js লাইব্রেরি CDN থেকে লোড হয়, তাই গেম চালানোর সময় ইন্টারনেট লাগবে।
- Android Studio (Giraffe বা নতুন) খুলে এই project folder open করুন।
- Android SDK Platform 35 ইনস্টল করুন এবং Gradle sync শেষ হতে দিন।
- Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
- APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ পাওয়া যাবে।

এই project-এ WebView দিয়ে HTML 3D game চালানো হয়। বাস্তব ডিভাইসে পরীক্ষা করুন।
